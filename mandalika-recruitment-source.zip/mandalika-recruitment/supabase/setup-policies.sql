-- Jalankan sekali di Supabase SQL Editor setelah tabel dibuat.
-- Kebijakan awal ini hanya mengizinkan pengguna yang sudah login.
-- Untuk penggunaan perusahaan, tambahkan pembatasan per role/area sebelum memasukkan data kandidat nyata.

alter table public.stores enable row level security;
alter table public.candidates enable row level security;
alter table public.candidate_stage_history enable row level security;
alter table public.interview_evaluations enable row level security;

drop policy if exists "Authenticated users can read stores" on public.stores;
create policy "Authenticated users can read stores"
on public.stores for select to authenticated using (true);

drop policy if exists "Authenticated users can manage stores" on public.stores;
create policy "Authenticated users can manage stores"
on public.stores for all to authenticated using (true) with check (true);

drop policy if exists "Authenticated users can read candidates" on public.candidates;
create policy "Authenticated users can read candidates"
on public.candidates for select to authenticated using (true);

drop policy if exists "Authenticated users can insert candidates" on public.candidates;
create policy "Authenticated users can insert candidates"
on public.candidates for insert to authenticated with check (true);

drop policy if exists "Authenticated users can update candidates" on public.candidates;
create policy "Authenticated users can update candidates"
on public.candidates for update to authenticated using (true) with check (true);

drop policy if exists "Authenticated users can read stage history" on public.candidate_stage_history;
create policy "Authenticated users can read stage history"
on public.candidate_stage_history for select to authenticated using (true);

drop policy if exists "Authenticated users can insert stage history" on public.candidate_stage_history;
create policy "Authenticated users can insert stage history"
on public.candidate_stage_history for insert to authenticated with check (true);

drop policy if exists "Authenticated users can read evaluations" on public.interview_evaluations;
create policy "Authenticated users can read evaluations"
on public.interview_evaluations for select to authenticated using (true);

drop policy if exists "Authenticated users can insert evaluations" on public.interview_evaluations;
create policy "Authenticated users can insert evaluations"
on public.interview_evaluations for insert to authenticated with check (true);

drop policy if exists "Authenticated users can update evaluations" on public.interview_evaluations;
create policy "Authenticated users can update evaluations"
on public.interview_evaluations for update to authenticated using (true) with check (true);
