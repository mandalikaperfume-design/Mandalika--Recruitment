# Mandalika Recruitment System

Starter website for Mandalika recruitment tracking, built with Next.js and Supabase.

## Features included
- Beige / ivory / gold HR portal UI
- Email + password login using Supabase Auth
- Dashboard counters
- Candidate creation and search
- Filter by store and recruitment stage
- Move candidates through HR Interview, User Interview, Pembekalan, Training, Kontrak
- Mark candidates as failed and retain them in the database
- Initial stage history logging

## Before using
This is a starter implementation. The current dashboard is a first working slice, not the complete final system. Candidate detail pages, full interview evaluation forms, role/area permissions, audit logging, and production hardening still need to be added.

Do not enter real candidate personal data until the company has approved the system and access policies have been reviewed. The included starter RLS policies allow any authenticated user to access all rows. This is suitable only for controlled testing with dummy data, not a multi-area production deployment.

## 1. Supabase
The project expects these tables:
- `stores`
- `candidates`
- `candidate_stage_history`
- `interview_evaluations`

These match the initial SQL schema created during setup.

In Supabase SQL Editor, run `supabase/setup-policies.sql` once. This creates authenticated-only starter policies. It does not implement area-level restrictions.

## 2. Create a login user
In Supabase Dashboard:
1. Authentication -> Users
2. Add user -> Create new user
3. Enter an HR test email and password.
4. Confirm the user if the dashboard offers that option.

Do not create a public sign-up page. Add accounts only through the administrator.

## 3. Environment variables
Copy `.env.example` to `.env.local` for local development, or add the same variables in Vercel Project Settings -> Environment Variables:

- `NEXT_PUBLIC_SUPABASE_URL`: Supabase Project URL
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`: Supabase publishable key (or legacy anon key)

Never use the Supabase `service_role` key or secret key in browser code, GitHub, or `NEXT_PUBLIC_` variables.

## 4. Deploy on Vercel
Import this GitHub repository into Vercel.
Framework: Next.js
Root Directory: `./`
Build command: `next build`
Install command: `npm install`

Add the two environment variables above, then Deploy.

## 5. Add the source code to GitHub
Upload the contents of this ZIP into the root of the `mandalika-recruitment` repository. The root should contain `package.json`, `app/`, `lib/`, `supabase/`, and this README. Do not upload the ZIP as a single file.

## 6. Local development (optional)
Requires Node.js 20.9 or newer:
```bash
npm install
cp .env.example .env.local
npm run dev
```

## Security and next steps
- Use dummy candidates during testing.
- Restrict repository access.
- Before production, implement user profiles and role/area-based Row Level Security.
- Review privacy, retention, backup, and company approval requirements.
- Never share database passwords or secret keys in chat.
