"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function signIn(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setMessage("");
    try {
      const supabase = createClient();
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      router.push("/dashboard");
      router.refresh();
    } catch (err) {
      setMessage(err instanceof Error ? err.message : "Login gagal.");
    } finally { setBusy(false); }
  }

  return <main className="loginShell">
    <div className="loginDecor"><span className="orb orbOne"/><span className="orb orbTwo"/>
      <div className="brandMark">M</div><p className="eyebrow">MANDALIKA PERFUMERY</p>
      <h1>People make<br/><em>the difference.</em></h1>
      <p className="loginIntro">Recruitment Management System</p>
      <div className="loginFoot">A thoughtful way to find the right people.</div>
    </div>
    <section className="loginPanel">
      <div className="panelInner">
        <p className="eyebrow goldText">WELCOME BACK</p>
        <h2>HR Portal</h2>
        <p className="muted">Masuk menggunakan akun HR yang telah dibuat oleh administrator.</p>
        <form onSubmit={signIn} className="loginForm">
          <label>Email<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="nama@perusahaan.com" required /></label>
          <label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Masukkan password" required /></label>
          {message && <div className="alert">{message}</div>}
          <button className="primaryButton" disabled={busy}>{busy ? "Memproses..." : "Masuk ke Dashboard"}</button>
        </form>
        <p className="tinyNote">Akun dibuat melalui Supabase Authentication. Registrasi publik tidak dibuka.</p>
      </div>
    </section>
  </main>;
}
