 "use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase";

const STAGES = ["HR Interview", "User Interview", "Pembekalan", "Training", "Kontrak"];
type Store = { id: string; store_name: string; area_name: string | null };
type Candidate = {
  id: string; full_name: string; whatsapp: string | null; domicile: string | null;
  store_id: string | null; current_stage: string; status: string;
  failure_stage: string | null; failure_reason: string | null; created_at: string;
};

export default function DashboardPage() {
  const router = useRouter();
  const supabase = useMemo(() => createClient(), []);
  const [userEmail, setUserEmail] = useState("");
  const [stores, setStores] = useState<Store[]>([]);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [stageFilter, setStageFilter] = useState("Semua tahap");
  const [storeFilter, setStoreFilter] = useState("Semua toko");
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState("");
  const [form, setForm] = useState({ full_name:"", whatsapp:"", domicile:"", store_id:"", current_stage:"HR Interview" });

  async function load() {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { router.replace("/login"); return; }
    setUserEmail(user.email || "");
    const [s, c] = await Promise.all([
      supabase.from("stores").select("id,store_name,area_name").order("store_name"),
      supabase.from("candidates").select("*").order("created_at", { ascending:false })
    ]);
    if (s.error) setNotice("Gagal memuat toko: " + s.error.message);
    if (c.error) setNotice("Gagal memuat kandidat: " + c.error.message);
    setStores(s.data || []); setCandidates(c.data || []); setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function logout() {
    await supabase.auth.signOut(); router.replace("/login"); router.refresh();
  }

  async function addCandidate(e: React.FormEvent) {
    e.preventDefault(); setSaving(true); setNotice("");
    const { data, error } = await supabase.from("candidates").insert({
      full_name: form.full_name.trim(), whatsapp: form.whatsapp || null,
      domicile: form.domicile || null, store_id: form.store_id || null,
      current_stage: form.current_stage, status: "Active"
    }).select().single();
    if (error) { setNotice(error.message); setSaving(false); return; }
    const { error: historyError } = await supabase.from("candidate_stage_history").insert({
      candidate_id: data.id, stage: form.current_stage, result: "Mulai proses", evaluator: userEmail, notes: "Kandidat ditambahkan ke database."
    });
    setNotice(historyError ? "Kandidat tersimpan, tetapi riwayat awal gagal dibuat: " + historyError.message : "Kandidat berhasil ditambahkan.");
    setForm({ full_name:"", whatsapp:"", domicile:"", store_id:"", current_stage:"HR Interview" });
    setShowForm(false); setSaving(false); await load();
  }

  async function moveCandidate(candidate: Candidate, stage: string) {
    const { error } = await supabase.from("candidates").update({ current_stage: stage, status: stage === "Kontrak" ? "Contract" : "Active" }).eq("id", candidate.id);
    if (error) { setNotice(error.message); return; }
    const { error: hError } = await supabase.from("candidate_stage_history").insert({
      candidate_id: candidate.id, stage, result: stage === "Kontrak" ? "Lolos" : "Lanjut tahap", evaluator: userEmail, notes: "Perubahan tahap melalui dashboard."
    });
    setNotice(hError ? "Tahap berubah, tetapi riwayat gagal disimpan: " + hError.message : "Tahap kandidat diperbarui.");
    await load();
  }

  async function failCandidate(candidate: Candidate) {
    const reason = window.prompt("Tuliskan alasan kandidat gagal:");
    if (reason === null) return;
    const { error } = await supabase.from("candidates").update({
      status: "Failed", failure_stage: candidate.current_stage, failure_reason: reason, current_stage: "Gagal"
    }).eq("id", candidate.id);
    if (error) { setNotice(error.message); return; }
    await supabase.from("candidate_stage_history").insert({
      candidate_id: candidate.id, stage: candidate.current_stage, result: "Gagal", evaluator: userEmail, notes: reason
    });
    setNotice("Kandidat dipindahkan ke arsip gagal."); await load();
  }

  const active = candidates.filter(c=>c.status !== "Failed");
  const filtered = candidates.filter(c => {
    const storeName = stores.find(s=>s.id===c.store_id)?.store_name || "";
    return (c.full_name.toLowerCase().includes(search.toLowerCase()) || (c.whatsapp||"").includes(search))
      && (stageFilter === "Semua tahap" || c.current_stage === stageFilter)
      && (storeFilter === "Semua toko" || c.store_id === storeFilter);
  });
  const countStage = (stage:string) => active.filter(c=>c.current_stage===stage).length;

  return <main className="appShell">
    <aside className="sidebar">
      <div className="sideBrand"><div className="brandMark small">M</div><div><strong>MANDALIKA</strong><span>RECRUITMENT</span></div></div>
      <div className="sideLabel">WORKSPACE</div>
      <div className="navItem selected">▦ <span>Dashboard</span></div>
      <div className="navItem">♧ <span>Database Kandidat</span></div>
      <div className="navItem">▤ <span>Recruitment Pipeline</span></div>
      <div className="navItem">▱ <span>Arsip Kandidat Gagal</span></div>
      <div className="sideBottom"><div className="avatar">HR</div><div className="userInfo"><b>HR Team</b><span>{userEmail}</span></div><button className="logout" onClick={logout} title="Keluar">↗</button></div>
    </aside>
    <section className="mainArea">
      <header className="topbar"><div><span className="eyebrow">TALENT ACQUISITION</span><h1>Recruitment Overview</h1></div><div className="topActions"><span className="dateTag">MANDALIKA · HR PORTAL</span><button className="primaryButton compact" onClick={()=>setShowForm(!showForm)}>＋ Tambah Kandidat</button></div></header>
      {notice && <div className="notice">{notice}<button onClick={()=>setNotice("")}>×</button></div>}
      <div className="metricGrid">
        <article className="metricCard"><span>Total Pelamar</span><strong>{candidates.length}</strong><small>Seluruh kandidat terdaftar</small></article>
        <article className="metricCard"><span>Proses Aktif</span><strong>{active.length}</strong><small>Kandidat dalam seleksi</small></article>
        <article className="metricCard"><span>Sedang Training</span><strong>{countStage("Training")}</strong><small>Dalam tahap training</small></article>
        <article className="metricCard"><span>Kontrak</span><strong>{countStage("Kontrak")}</strong><small>Berhasil menyelesaikan seleksi</small></article>
        <article className="metricCard"><span>Gagal Seleksi</span><strong>{candidates.filter(c=>c.status==="Failed").length}</strong><small>Tersimpan di arsip</small></article>
      </div>
      {showForm && <section className="contentCard formCard"><div className="sectionHead"><div><span className="eyebrow">NEW APPLICANT</span><h2>Tambah Kandidat</h2></div><button className="closeButton" onClick={()=>setShowForm(false)}>×</button></div>
        <form className="candidateForm" onSubmit={addCandidate}>
          <label>Nama lengkap<input required value={form.full_name} onChange={e=>setForm({...form,full_name:e.target.value})} placeholder="Nama kandidat"/></label>
          <label>Nomor WhatsApp<input value={form.whatsapp} onChange={e=>setForm({...form,whatsapp:e.target.value})} placeholder="08xxxxxxxxxx"/></label>
          <label>Domisili<input value={form.domicile} onChange={e=>setForm({...form,domicile:e.target.value})} placeholder="Kota/kecamatan"/></label>
          <label>Penempatan toko<select value={form.store_id} onChange={e=>setForm({...form,store_id:e.target.value})}><option value="">Pilih toko</option>{stores.map(s=><option key={s.id} value={s.id}>{s.store_name} — {s.area_name}</option>)}</select></label>
          <label>Tahap awal<select value={form.current_stage} onChange={e=>setForm({...form,current_stage:e.target.value})}>{STAGES.slice(0,4).map(s=><option key={s}>{s}</option>)}</select></label>
          <div className="formActions"><button className="primaryButton" disabled={saving}>{saving?"Menyimpan...":"Simpan Kandidat"}</button></div>
        </form>
      </section>}
      <section className="contentCard">
        <div className="sectionHead"><div><span className="eyebrow">CANDIDATE TRACKER</span><h2>Database Kandidat</h2><p className="muted">Pantau progres kandidat dari satu tempat.</p></div><span className="countPill">{filtered.length} kandidat</span></div>
        <div className="filterRow"><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Cari nama atau WhatsApp..."/><select value={storeFilter} onChange={e=>setStoreFilter(e.target.value)}><option value="Semua toko">Semua toko</option>{stores.map(s=><option key={s.id} value={s.id}>{s.store_name}</option>)}</select><select value={stageFilter} onChange={e=>setStageFilter(e.target.value)}><option>Semua tahap</option>{[...STAGES,"Gagal"].map(s=><option key={s}>{s}</option>)}</select></div>
        {loading ? <p className="muted pad">Memuat database...</p> : filtered.length===0 ? <div className="emptyState"><div>✧</div><b>Belum ada kandidat</b><span>Tambahkan kandidat pertama untuk mulai menggunakan sistem.</span></div> :
        <div className="tableWrap"><table><thead><tr><th>Nama Kandidat</th><th>WhatsApp</th><th>Penempatan</th><th>Tahap</th><th>Status</th><th>Aksi</th></tr></thead><tbody>
          {filtered.map(c=><tr key={c.id}><td><b>{c.full_name}</b><small>{c.domicile||"Domisili belum diisi"}</small></td><td>{c.whatsapp||"—"}</td><td>{stores.find(s=>s.id===c.store_id)?.store_name||"—"}</td><td><span className="stageTag">{c.current_stage}</span></td><td><span className={c.status==="Failed"?"status failed":c.status==="Contract"?"status contract":"status active"}>{c.status==="Failed"?"Gagal":c.status==="Contract"?"Kontrak":"Aktif"}</span></td><td><div className="rowActions">{c.status!=="Failed" && c.current_stage!=="Kontrak" && <select aria-label="Pindahkan tahap" defaultValue="" onChange={e=>{if(e.target.value) moveCandidate(c,e.target.value);e.target.value="";}}><option value="">Pindah tahap</option>{STAGES.filter(s=>STAGES.indexOf(s)>STAGES.indexOf(c.current_stage)).map(s=><option key={s}>{s}</option>)}</select>}{c.status!=="Failed" && <button className="textAction" onClick={()=>failCandidate(c)}>Gagalkan</button>}</div></td></tr>)}
        </tbody></table></div>}
      </section>
      <footer className="footerNote">MANDALIKA PERFUMERY <span>·</span> RECRUITMENT MANAGEMENT SYSTEM</footer>
    </section>
  </main>;
}
